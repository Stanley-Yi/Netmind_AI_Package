# NetMind_AI_XYZ

Author: Netmind.AI, BlackSheep Team

## Project-XYZ

The FIRST step for building the AI-Kingdom 

## Introduction:

![](documents/figures/structure.jpg)


## Month-1 Task

Xiangpeng:

![](documents/figures/month_1.jpg)


```bash
.
├── documents
│   ├── docs
│   │   └── README.md
│   └── figures
│       ├── month_1.jpg
│       └── structure.jpg
├── netmindxyz
│   ├── company
│   │   └── README.md
│   ├── government
│   │   └── README.md
│   ├── magics
│   │   └── README.md
│   └── school
│       └── README.md
├── README.md
└── requirements.txt
```

### Government




### Company 





### School




### Magics(technologys)

